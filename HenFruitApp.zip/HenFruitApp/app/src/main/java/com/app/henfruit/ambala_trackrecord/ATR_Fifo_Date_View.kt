package com.app.henfruit.ambala_trackrecord

import android.graphics.Paint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.databinding.ActivityAtrFifoDateViewBinding
import com.app.henfruit.databinding.ActivityAtrrStockByEggTypeBinding
import com.app.henfruit.viewmodel.ATRBarcodeRequestViewModel

class ATR_Fifo_Date_View : AppCompatActivity() {

    private lateinit var binding: ActivityAtrFifoDateViewBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize DataBinding
        binding = DataBindingUtil.setContentView(this, R.layout.activity_atr_fifo_date_view)
        binding.lifecycleOwner = this
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        // Back button functionality
        binding.backImg.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Swipe-to-refresh
        binding.srlRefresh.setOnRefreshListener {
            binding.srlRefresh.isRefreshing = false
            reloadDynamicList() // Refresh dynamic list items
        }

        // Initial load
        reloadDynamicList()
    }

    private fun reloadDynamicList() {
        // Clear existing items
        binding.dynamicLl.removeAllViews()

        // Simulate adding 4 items
        for (i in 0..13) {
            addHospitalItem(i)
        }
    }

    private fun addHospitalItem(index: Int) {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.dynamic_report, binding.dynamicLl, false)

        // Add to layout
        binding.dynamicLl.addView(view)

        // Optional: separator
        val separator = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1
            ).apply {
                topMargin = 8
                bottomMargin = 8
            }
            setBackgroundColor(resources.getColor(android.R.color.darker_gray))
        }

        binding.dynamicLl.addView(separator)
    }
}