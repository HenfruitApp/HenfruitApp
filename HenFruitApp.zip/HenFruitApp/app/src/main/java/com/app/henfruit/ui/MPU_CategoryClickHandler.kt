package com.app.henfruit.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_Breakage_Reporting
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_Cleaning_Progress
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_Current_GRN
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_ItemWise_Progress
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_Machine_Floor_Transfer
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_Machine_Packing_Update
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_PrePacked_StockEntry
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_PrintCommand_FgStock
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_View_Entries

class MPU_CategoryClickHandler(private val context: Context) {

    fun onCategoryClick(categoryName: String) {
        // You can log or debug categoryName here if needed

        when (categoryName) {
            "Item wise progress" -> context.startActivity(Intent(context, MPU_ItemWise_Progress::class.java))
            "Current GRN" -> context.startActivity(Intent(context, MPU_Current_GRN::class.java))
            "Machine Packing Update" -> context.startActivity(Intent(context, MPU_Machine_Packing_Update::class.java))
            "View Entries" -> context.startActivity(Intent(context, MPU_View_Entries::class.java))
            "Breakage Reporting" -> context.startActivity(Intent(context, MPU_Breakage_Reporting::class.java))
            "Cleaning Progress" -> context.startActivity(Intent(context, MPU_Cleaning_Progress::class.java))
            "Machine Floor Transfer" -> context.startActivity(Intent(context, MPU_Machine_Floor_Transfer::class.java))
            "Print command for FG stock" -> context.startActivity(Intent(context, MPU_PrintCommand_FgStock::class.java))
            "Pre packed stock entries check",
            "Pre Packed stock entry" -> context.startActivity(Intent(context, MPU_PrePacked_StockEntry::class.java))

            else -> Toast.makeText(context, "No activity mapped for \"$categoryName\"", Toast.LENGTH_SHORT).show()
        }
    }
}
