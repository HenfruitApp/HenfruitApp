package com.app.henfruit
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.app.henfruit.databinding.ActivityMainBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private lateinit var db : DatabaseReference
    private var isPasswordVisible = false  // For toggling visibility

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Show/Hide Password toggle
        binding.togglePass.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                binding.ed3.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                binding.togglePass.setImageResource(R.drawable.ic_baseline_visibility_off_24)
            } else {
                binding.ed3.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                binding.togglePass.setImageResource(R.drawable.ic_baseline_visibility_24)
            }
            binding.ed3.setSelection(binding.ed3.text?.length ?: 0)
        }

        binding.btnRigis.setOnClickListener {
            val name = binding.ed1.text.toString().trim()
            val username = binding.ed2.text.toString().trim()
            val password = binding.ed3.text.toString().trim()

            if (name.isEmpty() || username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show()
            } else if (password.length < 6) {
                val alert = AlertDialog.Builder(this)
                alert.setTitle("Invalid Password")
                alert.setMessage("Password must be at least 6 characters long")
                alert.setPositiveButton("OK", null)
                alert.show()
            } else {
                db = FirebaseDatabase.getInstance().getReference("Users")
                val user = Users(name, username, password)
                db.child(username).setValue(user).addOnSuccessListener {
                    val ad = AlertDialog.Builder(this)
                    ad.setTitle("Message")
                    ad.setMessage("Account registered successfully")
                    ad.setPositiveButton("Ok") { _, _ ->
                        // Clear the fields
                        binding.ed1.text.clear()
                        binding.ed2.text.clear()
                        binding.ed3.text.clear()

                        // Navigate to login screen
                        val intent = Intent(this, login_form::class.java)
                        startActivity(intent)
                        finish() // Optional: finish current activity to prevent going back
                    }
                    ad.show()
                }.addOnFailureListener {
                    val ad = AlertDialog.Builder(this)
                    ad.setTitle("Message")
                    ad.setMessage("Account not registered")
                    ad.setPositiveButton("Ok", null)
                    ad.show()
                }
            }
        }
        binding.loginLink.setOnClickListener {
            val intent=Intent(this,login_form::class.java)
            startActivity(intent)
        }
    }
}