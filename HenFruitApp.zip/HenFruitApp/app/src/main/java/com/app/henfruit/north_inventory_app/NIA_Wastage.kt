package com.app.henfruit.north_inventory_app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.common.ToolbarHandler
import com.app.henfruit.databinding.ActivityNiaWastageBinding

class NIA_Wastage : AppCompatActivity() {

    private lateinit var binding: ActivityNiaWastageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_nia_wastage)
        binding.lifecycleOwner = this

        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        val toolbarHandler = ToolbarHandler(this)
        toolbarHandler.setTitle("Wastage")

        binding.handler = toolbarHandler
    }
}
