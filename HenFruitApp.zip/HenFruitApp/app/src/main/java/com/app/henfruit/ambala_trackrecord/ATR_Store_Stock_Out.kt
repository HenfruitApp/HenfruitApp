package com.app.henfruit.ambala_trackrecord

import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.app.henfruit.R

class ATR_Store_Stock_Out : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_atr_store_stock_out)
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        // Handle window insets (optional UI polish)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Back button functionality
        val backButton: ImageView = findViewById(R.id.menuImg)
        backButton.setOnClickListener {
            finish() // Close the current activity and go back
        }
    }
}
