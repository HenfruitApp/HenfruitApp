package com.app.henfruit

data class Users(val name: String? = null, val username: String? = null,val pasword: String? = null){

}
