package com.app.henfruit.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.app.henfruit.ambala_trackrecord.ATRR_stock_by_egg_type
import com.app.henfruit.ambala_trackrecord.ATR_Barcode_Request
import com.app.henfruit.ambala_trackrecord.ATR_Fifo_Date_View
import com.app.henfruit.ambala_trackrecord.ATR_Grn
import com.app.henfruit.ambala_trackrecord.ATR_INWARDQC
import com.app.henfruit.ambala_trackrecord.ATR_I_store_Inward
import com.app.henfruit.ambala_trackrecord.ATR_New_Farm_Creation
import com.app.henfruit.ambala_trackrecord.ATR_Stock_store_wise
import com.app.henfruit.ambala_trackrecord.ATR_Store_Stock_Out

class CategoryClickHandler(private val context: Context) {

    fun onCategoryClick(categoryName: String) {
      //  Toast.makeText(context, "Clicked: $categoryName", Toast.LENGTH_SHORT).show()

        // Example: Start a new activity based on category
        when (categoryName) {
            "GRN" -> context.startActivity(Intent(context, ATR_Grn::class.java))


            "Stock By Egg Type" -> context.startActivity(Intent(context, ATRR_stock_by_egg_type::class.java))
            "Stock Store Wise" -> context.startActivity(Intent(context, ATR_Stock_store_wise::class.java))
            "Fifo Date View 2" -> context.startActivity(Intent(context, ATR_Fifo_Date_View::class.java))

            "Inward QC" -> context.startActivity(Intent(context, ATR_INWARDQC::class.java))
            "New Farm Creation" -> context.startActivity(Intent(context, ATR_New_Farm_Creation::class.java))

            "I Store Inwards" -> context.startActivity(Intent(context, ATR_I_store_Inward::class.java))
            "Barcode Request" -> context.startActivity(Intent(context, ATR_Barcode_Request::class.java))
            "I Store Stock Out" -> context.startActivity(Intent(context, ATR_Store_Stock_Out::class.java))
            // Add all other categories here...
            else -> Toast.makeText(context, "No activity mapped for $categoryName", Toast.LENGTH_SHORT).show()
        }
    }
}
