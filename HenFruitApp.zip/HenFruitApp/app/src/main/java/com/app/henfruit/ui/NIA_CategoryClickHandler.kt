package com.app.henfruit.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.app.henfruit.north_inventory_app.NIA_Issue_Stock
import com.app.henfruit.north_inventory_app.NIA_Purchase
import com.app.henfruit.north_inventory_app.NIA_StockIn_ReverseIssue
import com.app.henfruit.north_inventory_app.NIA_StockTransfer
import com.app.henfruit.north_inventory_app.NIA_Wastage

class NIA_CategoryClickHandler(private val context: Context) {
    fun onCategoryClick(categoryName: String) {
        //  Toast.makeText(context, "Clicked: $categoryName", Toast.LENGTH_SHORT).show()

        // Example: Start a new activity based on category
        when (categoryName) {
            "Purchase" -> context.startActivity(Intent(context, NIA_Purchase::class.java))
            "Issue Stock" -> context.startActivity(Intent(context, NIA_Issue_Stock::class.java))
            "Stock In(Reverse Issue)" -> context.startActivity(Intent(context, NIA_StockIn_ReverseIssue::class.java))
            "Stock Transfer" -> context.startActivity(Intent(context, NIA_StockTransfer::class.java))
            "Wastage" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Copy data to order maker" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Issue PO" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Issue Stock Entries" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "New Article Creation" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Order Maker" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Order Sheet" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Purchase Entries" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Stock In(Reverse Issue)Entries" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Stock Transfer" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
//            "Summary" -> context.startActivity(Intent(context, NIA_Wastage::class.java))
             // Add all other categories here...
            else -> Toast.makeText(context, "No activity mapped for $categoryName", Toast.LENGTH_SHORT).show()
        }
    }
}
