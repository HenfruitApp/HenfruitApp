package com.app.henfruit.ambala_trackrecord.ATR_Model

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.Users
import com.app.henfruit.databinding.ActivityNiaCategoryListBinding
import com.app.henfruit.databinding.BottomNavBinding
import com.app.henfruit.ui.Account
import com.app.henfruit.ReusableCode.BottomNavHandler
import com.app.henfruit.ui.NIA_CategoryClickHandler

class NIA_CategoryList : AppCompatActivity() {

    private lateinit var binding: ActivityNiaCategoryListBinding
    private lateinit var navHandler: BottomNavHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_nia_category_list)
        binding.lifecycleOwner = this
// Set user object if needed (optional)
        val user = Users() // ← replace with actual user data if available
        binding.user = user

        // Bind click handler for category buttons
        binding.handler = NIA_CategoryClickHandler(this)

        // Setup bottom nav
        navHandler = BottomNavHandler(this)
        setupBottomNavListeners()

        // Setup profile image click
        setupHeaderProfileClick()
    }

    private fun setupHeaderProfileClick() {
        binding.header.findViewById<View>(R.id.profile_icon)?.setOnClickListener {
            startActivity(Intent(this, Account::class.java))
            Toast.makeText(this, "Profile clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBottomNavListeners() {
        val bottomNavView = binding.root.findViewById<View>(R.id.bottomNav)
        val bottomNavBinding = BottomNavBinding.bind(bottomNavView)

        bottomNavBinding.navHomeContainer.setOnClickListener { navHandler.onHomeClick(it) }
        bottomNavBinding.navTrackContainer.setOnClickListener { navHandler.onTrackClick(it) }
        bottomNavBinding.navPackingContainer.setOnClickListener { navHandler.onPackingClick(it) }
        bottomNavBinding.navProfileContainer.setOnClickListener { navHandler.onProfileClick(it) }
    }
}
