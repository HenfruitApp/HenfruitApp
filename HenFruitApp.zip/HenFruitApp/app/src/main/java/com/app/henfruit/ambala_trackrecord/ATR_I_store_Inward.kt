package com.app.henfruit.ambala_trackrecord

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.databinding.ActivityAtrGrnBinding
import com.app.henfruit.databinding.ActivityAtrIstoreInwardBinding

class ATR_I_store_Inward : AppCompatActivity() {

    private lateinit var binding: ActivityAtrIstoreInwardBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable DataBinding
        binding = DataBindingUtil.setContentView(this, R.layout.activity_atr_istore_inward)
        binding.lifecycleOwner = this
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        // Back button click
        binding.menuImg.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // TODO: Setup GRN Spinner items if needed
        // e.g., you can call viewModel.loadGrnItems() and observe LiveData
    }
}