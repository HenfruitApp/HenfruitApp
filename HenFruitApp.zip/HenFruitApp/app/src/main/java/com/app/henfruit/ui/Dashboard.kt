// Dashboard.java (converted from your Kotlin logic)
package com.app.henfruit.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.app.henfruit.MachinePackegingUpdate.MPU_Model.MPU_CategoryList
import com.app.henfruit.R
import com.app.henfruit.ReusableCode.BottomNavHandler
import com.app.henfruit.ambala_trackrecord.ATR_Model.Das_CategoryList
import com.app.henfruit.ambala_trackrecord.ATR_Model.NIA_CategoryList
import com.app.henfruit.databinding.ActivityDashboardBinding
import com.app.henfruit.databinding.BottomNavBinding

class Dashboard : AppCompatActivity() {
    private var binding: ActivityDashboardBinding? = null
    private var navHandler: BottomNavHandler? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_dashboard)
        navHandler = BottomNavHandler(this)

       // setupCardListeners()
        setupBottomNavListeners()
        // Registration link
        binding!!.catImg.setOnClickListener {
            val intent = Intent(this, Das_CategoryList::class.java)
            startActivity(intent)
        }

        binding!!.niaCatImg.setOnClickListener {
            val intent = Intent(this, NIA_CategoryList::class.java)
            startActivity(intent)
        }

        binding!!.mpuCatImg.setOnClickListener {
            val intent = Intent(this, MPU_CategoryList::class.java)
            startActivity(intent)
        }
    }

//    private fun setupCardListeners() {
//        binding!!.card1.setOnClickListener { v -> showToast(v.tag.toString()) }
//        binding!!.card2.setOnClickListener { v -> showToast(v.tag.toString()) }
//        binding!!.card3.setOnClickListener { v -> showToast(v.tag.toString()) }
//    }

    private fun setupBottomNavListeners() {
        val bottomNav: View = binding!!.root.findViewById(R.id.bottomNav)
        val bottomNavBinding = BottomNavBinding.bind(bottomNav)

        bottomNavBinding.navHomeContainer.setOnClickListener { view: View ->
            navHandler!!.onHomeClick(
                view
            )
        }
        bottomNavBinding.navTrackContainer.setOnClickListener { view: View ->
            navHandler!!.onTrackClick(
                view
            )
        }
        bottomNavBinding.navPackingContainer.setOnClickListener { view: View ->
            navHandler!!.onPackingClick(
                view
            )
        }
        bottomNavBinding.navProfileContainer.setOnClickListener { view: View ->
            navHandler!!.onProfileClick(
                view
            )
        }
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

}