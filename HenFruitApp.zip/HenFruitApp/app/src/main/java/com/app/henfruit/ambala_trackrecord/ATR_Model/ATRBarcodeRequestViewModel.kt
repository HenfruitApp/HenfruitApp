package com.app.henfruit.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ATRBarcodeRequestViewModel : ViewModel() {

    // Quantity (default = 1)
    private val _quantity = MutableLiveData(1)
    val quantity: LiveData<Int> = _quantity

    fun increaseQuantity() {
        val current = _quantity.value ?: 1
        _quantity.value = current + 1
    }

    fun decreaseQuantity() {
        val current = _quantity.value ?: 1
        if (current > 1) {
            _quantity.value = current - 1
        }
    }

    fun onSaveClick() {
        // Handle save logic here
        val qty = _quantity.value ?: 0
        Log.d("ATRBarcodeRequest", "Saving Quantity: $qty")

        // You can show a Toast, update DB, or call Repository here.
    }
}
