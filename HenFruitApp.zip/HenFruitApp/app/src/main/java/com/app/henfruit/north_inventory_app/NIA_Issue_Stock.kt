package com.app.henfruit.north_inventory_app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.common.ToolbarHandler
import com.app.henfruit.databinding.ActivityNiaIssueStockBinding

class NIA_Issue_Stock : AppCompatActivity() {

    private lateinit var binding: ActivityNiaIssueStockBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set up DataBinding
        binding = DataBindingUtil.setContentView(this, R.layout.activity_nia_issue_stock)
        binding.lifecycleOwner = this

        // Status bar color
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        // Toolbar setup
        val toolbarHandler = ToolbarHandler(this)
        toolbarHandler.setTitle("Issue Stock")
        binding.handler = toolbarHandler
    }
}
