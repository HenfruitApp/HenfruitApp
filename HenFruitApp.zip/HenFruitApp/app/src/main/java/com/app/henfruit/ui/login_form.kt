package com.app.henfruit

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.app.henfruit.databinding.ActivityLoginFormBinding
import com.app.henfruit.ui.Account
import com.app.henfruit.ui.Dashboard
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class login_form : AppCompatActivity() {
    private lateinit var bind: ActivityLoginFormBinding
    private lateinit var db: DatabaseReference
    private var username: String = ""
    private var password: String = ""
    private var isPasswordVisible = false  // For toggling visibility

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityLoginFormBinding.inflate(layoutInflater)
        setContentView(bind.root)

        // Registration link
        bind.regisLink.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Show/Hide Password toggle
        bind.togglePass.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                bind.ed3.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                bind.togglePass.setImageResource(R.drawable.ic_baseline_visibility_off_24)
            } else {
                bind.ed3.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                bind.togglePass.setImageResource(R.drawable.ic_baseline_visibility_24)
            }
            bind.ed3.setSelection(bind.ed3.text?.length ?: 0)
        }

        // Login button click
        bind.btnLogin.setOnClickListener {
            username = bind.logtxt.text.toString()
            password = bind.ed3.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else if (password.length < 6) {
                val alert = AlertDialog.Builder(this)
                alert.setTitle("Invalid Password")
                alert.setMessage("Password must be at least 6 characters long")
                alert.setPositiveButton("OK", null)
                alert.show()
            } else {
                fetch_data(username)
            }
        }
    }

    private fun fetch_data(username: String) {
        db = FirebaseDatabase.getInstance().getReference("Users")
        db.child(username).get().addOnSuccessListener {
            if (it.exists()) {
                val psswrd = it.child("pasword").value.toString()
                val name = it.child("name").value.toString()
                if (password == psswrd) {
                    startActivity(Intent(this, Dashboard::class.java))
                   // startActivity(Intent(this, Dashboard::class.java).putExtra("name", name))
                } else {
                    showErrorDialog("Failed to login")
                }
            } else {
                showErrorDialog("Failed to login")
            }
        }
    }

    private fun showErrorDialog(message: String) {
        val ad = AlertDialog.Builder(this)
        ad.setTitle("Message")
        ad.setMessage(message)
        ad.setPositiveButton("Ok", null)
        ad.show()
    }

}
