package com.app.henfruit.ReusableCode

import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.Toast
import com.app.henfruit.ui.Account
import com.app.henfruit.ui.Dashboard

class BottomNavHandler(private val context: Context) {

    fun onHomeClick(view: View) {
        context.startActivity(Intent(context, Dashboard::class.java))
        Toast.makeText(context, "Home clicked", Toast.LENGTH_SHORT).show()
    }

    fun onTrackClick(view: View) {
        Toast.makeText(context, "Track clicked", Toast.LENGTH_SHORT).show()
    }

    fun onPackingClick(view: View) {
        Toast.makeText(context, "Packing clicked", Toast.LENGTH_SHORT).show()
    }

    fun onProfileClick(view: View) {
        context.startActivity(Intent(context, Account::class.java))
        Toast.makeText(context, "Profile clicked", Toast.LENGTH_SHORT).show()
    }
}
