package com.app.henfruit.north_inventory_app


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.common.ToolbarHandler
import com.app.henfruit.databinding.ActivityNiaStockTransferBinding

class NIA_StockTransfer : AppCompatActivity() {

    private lateinit var binding: ActivityNiaStockTransferBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_nia_stock_transfer)
        binding.lifecycleOwner = this

        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        val toolbarHandler = ToolbarHandler(this)
        toolbarHandler.setTitle("Stock Transfer")
        binding.handler = toolbarHandler
    }
}
