package com.app.henfruit.ambala_trackrecord

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.databinding.ActivityAtrBarcodeRequestBinding
import com.app.henfruit.viewmodel.ATRBarcodeRequestViewModel

class ATR_Barcode_Request : AppCompatActivity() {

    private lateinit var binding: ActivityAtrBarcodeRequestBinding
    private val viewModel: ATRBarcodeRequestViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable DataBinding
        binding = DataBindingUtil.setContentView(this, R.layout.activity_atr_barcode_request)
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        // Bind ViewModel to layout
        binding.viewModel = viewModel
        binding.lifecycleOwner = this

        // Back button click
        binding.menuImg.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // TODO: Setup GRN Spinner items if needed
        // e.g., you can call viewModel.loadGrnItems() and observe LiveData
    }
}
