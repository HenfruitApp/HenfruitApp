package com.app.henfruit.north_inventory_app

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.databinding.DataBindingUtil
import com.app.henfruit.R
import com.app.henfruit.common.ToolbarHandler
import com.app.henfruit.databinding.ActivityNiaStockInReverseIssueBinding

class NIA_StockIn_ReverseIssue : AppCompatActivity() {

    private lateinit var binding: ActivityNiaStockInReverseIssueBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Enable DataBinding
        binding = DataBindingUtil.setContentView(this, R.layout.activity_nia_stock_in_reverse_issue)
        binding.lifecycleOwner = this
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple_700)

        // toolbar header seperate class call
        val toolbarHandler = ToolbarHandler(this)
        toolbarHandler.setTitle("Stock In(Reverse Issue)")
        // ✅ Set handler in the parent binding, NOT customToolbar
        binding.handler = toolbarHandler
    }
}