package com.app.henfruit.common

import android.app.Activity
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData

class ToolbarHandler(private val activity: AppCompatActivity) {

    // Observable title (optional: bind this to your layout)
    val toolbarTitle = MutableLiveData<String>()

    // Back button handler
    val onBackClick = View.OnClickListener {
        activity.onBackPressedDispatcher.onBackPressed()
    }

    // Optional: Add more common click handlers here
    val onMenuClick = View.OnClickListener {
        // Future: open drawer or show menu
    }

    fun setTitle(title: String) {
        toolbarTitle.value = title
    }
}
